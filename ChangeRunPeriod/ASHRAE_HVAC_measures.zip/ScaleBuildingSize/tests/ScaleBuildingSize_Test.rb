require 'openstudio'

require 'openstudio/ruleset/ShowRunnerOutput'

require "#{File.dirname(__FILE__)}/../measure.rb"

require 'test/unit'

class ScaleBuildingSize_Test < Test::Unit::TestCase

  
  def test_ScaleBuildingSize
     
    # create an instance of the measure
    measure = ScaleBuildingSize.new
    
    # create an instance of a runner
    runner = OpenStudio::Ruleset::OSRunner.new
    
    # make an empty model
    model = OpenStudio::Model::Model.new
    
    # get arguments and test that they are what we are expecting
    arguments = measure.arguments(model)
    assert_equal(3, arguments.size)
    assert_equal("x_scale", arguments[0].name)
    assert_equal("y_scale", arguments[1].name)
    assert_equal("z_scale", arguments[2].name)
    
    # make example model
    model = OpenStudio::Model::exampleModel    
    
    building = model.getBuilding
    floorArea = building.floorArea
    assert(floorArea > 0)

    # set argument values to good values and run the measure on model with spaces
    argument_map = OpenStudio::Ruleset::OSArgumentMap.new
    x_scale = arguments[0].clone
    assert(x_scale.setValue(2))
    argument_map["x_scale"] = x_scale
    y_scale = arguments[1].clone
    assert(y_scale.setValue(3))
    argument_map["y_scale"] = y_scale
    z_scale = arguments[2].clone
    assert(z_scale.setValue(3))
    argument_map["z_scale"] = z_scale    
    
    measure.run(model, runner, argument_map)
    result = runner.result
    assert(result.value.valueName == "Success")
       
    newFloorArea = building.floorArea
    assert(newFloorArea > 0)
    assert_equal(2*3*floorArea, newFloorArea)
   
  end  

end
